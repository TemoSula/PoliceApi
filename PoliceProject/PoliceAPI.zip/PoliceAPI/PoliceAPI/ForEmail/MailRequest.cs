﻿using System.Security.Cryptography.X509Certificates;

namespace PoliceAPI.ForEmail
{
    public class MailRequest
    {
        
        public string ToEmail { get; set; }
        public string Subject { get; set; }

        public string Body { get; set; }


    }
}
