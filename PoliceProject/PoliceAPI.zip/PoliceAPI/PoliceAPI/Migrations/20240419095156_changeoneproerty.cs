﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PoliceAPI.Migrations
{
    /// <inheritdoc />
    public partial class changeoneproerty : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "UserName",
                table: "CarInfos",
                newName: "LastName");

            migrationBuilder.AddColumn<string>(
                name: "FirstName",
                table: "CarInfos",
                type: "nvarchar(30)",
                maxLength: 30,
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "FirstName",
                table: "CarInfos");

            migrationBuilder.RenameColumn(
                name: "LastName",
                table: "CarInfos",
                newName: "UserName");
        }
    }
}
