﻿namespace PoliceAPI.Dtos
{
    public class PayAndStatusForBikeDto
    {

      

        public string PayStatus { get; set; }

    }
}
