﻿using Microsoft.EntityFrameworkCore;
using PoliceAPI.Entities;

namespace PoliceAPI.Repositories
{
    public class CarFineRepository : ICarFineRepository

    {
        private readonly PoliceApiDbContext _context;
        public CarFineRepository(PoliceApiDbContext context)
        {
            _context = context;
        }

        public async Task<CarFine> AddFineOnCar(CarFine carFine)
        {

            await _context.CarFines.AddAsync(carFine);
            _context.SaveChanges();
            return carFine;

        }

        public async Task<CarFine> GetCarFineCheckAndCarNumber(string CarNumber, string CheckNumber)
        {

            return await _context.CarFines.FirstOrDefaultAsync(x => x.CarNumber == CarNumber && x.CheckNumber == CheckNumber);

        }

        public async Task<CarFine> Update(string CarNumber, string CheckNumber, string payStatus)
        {
            var existingBikeFine = await _context.CarFines.FirstOrDefaultAsync(x => x.CarNumber == CarNumber && x.CheckNumber == CheckNumber);

            if (existingBikeFine != null)
            {
                // Update the existing bike fine entity with the new pay status
                existingBikeFine.PayStatus = payStatus;

                // Save changes to the database
                await _context.SaveChangesAsync();
            }

            return existingBikeFine;
        }
    }
}
