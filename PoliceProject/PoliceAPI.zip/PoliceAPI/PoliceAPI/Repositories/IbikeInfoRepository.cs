﻿using PoliceAPI.Entities;

namespace PoliceAPI.Repositories
{
    public interface IbikeInfoRepository
    {

        IEnumerable<BikeInfo> GetAllB();
        BikeInfo GetById(string BikeNumber);

        BikeInfo CreateBikeInfo(BikeInfo bikeInfo);

       
    }
}
