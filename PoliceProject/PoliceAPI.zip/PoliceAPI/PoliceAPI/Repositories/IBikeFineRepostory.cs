﻿using PoliceAPI.Dtos;
using PoliceAPI.Entities;

namespace PoliceAPI.Repositories
{
    public interface IBikeFineRepostory
    {

        Task<BikeFine> GetBikeFineCheckAndCarNumber(string BikeNumber, string CheckNumber);
        Task<BikeFine> AddFine(BikeFine bikeFine);

        Task<BikeFine> Update(string bikeNumber, string CheckNumber, string payStatus);

    }
}
