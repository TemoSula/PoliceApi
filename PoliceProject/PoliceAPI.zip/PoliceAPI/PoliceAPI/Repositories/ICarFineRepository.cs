﻿using PoliceAPI.Entities;

namespace PoliceAPI.Repositories
{
    public interface ICarFineRepository
    {

        Task<CarFine> GetCarFineCheckAndCarNumber(string CarNumber, string CheckNumber);
        Task<CarFine> AddFineOnCar(CarFine carFine);

        Task<CarFine> Update(string CarNumber, string CheckNumber, string payStatus);


    }
}
