﻿using PoliceAPI.Entities;

namespace PoliceAPI.Repositories
{
    public interface ICarInfoRepository
    {

        IEnumerable<CarInfo> GetAllN();
        CarInfo GetByCarNumber(string CarNumber);

        CarInfo AddCarInfo(CarInfo carInfo);




    }
}
