﻿using Microsoft.EntityFrameworkCore;
using PoliceAPI.Entities;


namespace PoliceAPI.Repositories
{
    public class CarInfoRepository : ICarInfoRepository
    {

        private readonly PoliceApiDbContext _context;
        public CarInfoRepository(PoliceApiDbContext context)
        {

            _context = context;

        }

        public IEnumerable<CarInfo> GetAllN()
        {
            return _context.CarInfos.ToList();
        }

        public CarInfo AddCarInfo(CarInfo carInfo)
        {
            _context.CarInfos.Add(carInfo);
            _context.SaveChanges();
            return carInfo;
        }
       
        public CarInfo GetByCarNumber(string CarNumber)
        {
            
            return _context.CarInfos.FirstOrDefault(x => x.CarNumber == CarNumber);
        }

       
    }
}
