﻿using System.Collections.Generic;

namespace PoliceAPI.Entities
{
    public class User
    {

        public int Id { get; set; }

        public string UserName { get; set; }

        public byte[] passwordHash { get; set; }

        public byte[] passwordSalt { get; set; }

        public DateTime Created { get; set; } = DateTime.Now;

        //ICollection
        public ICollection<UserRole> UserRoles { get; set; }
    }
}
