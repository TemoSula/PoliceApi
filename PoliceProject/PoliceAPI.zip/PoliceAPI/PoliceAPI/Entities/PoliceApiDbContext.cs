﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;


namespace PoliceAPI.Entities
{
    public class PoliceApiDbContext : DbContext
    {
        public PoliceApiDbContext(DbContextOptions<PoliceApiDbContext> options) : base(options) 
        {
        
        }
        

        public DbSet<CarInfo> CarInfos { get; set; }
        public DbSet<BikeInfo> BikeInfos { get; set; }

        public DbSet<CarFine> CarFines { get; set; }
        public DbSet<BikeFine> BikeFines { get; set; }

        public DbSet<Role> Roles { get; set; }
        public DbSet<User> Users{ get; set; }
        
        public DbSet<UserRole> UserRoles { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<CarFine>().HasKey(c => c.Id);
            modelBuilder.Entity<CarFine>().Property(c => c.CarNumber).IsRequired().HasMaxLength(20);
            modelBuilder.Entity<CarFine>().Property(x => x.Amount).IsRequired().HasMaxLength(30);
            modelBuilder.Entity<CarFine>().Property(x => x.Reason).IsRequired().HasMaxLength(15);
            modelBuilder.Entity<CarFine>().Property(x => x.CheckNumber).IsRequired().HasMaxLength(25);
            modelBuilder.Entity<CarFine>().Property(x => x.Gmail).IsRequired().HasMaxLength(35);




            modelBuilder.Entity<BikeFine>().HasKey(c => c.Id);
            modelBuilder.Entity<BikeFine>().Property(c => c.BikeNumber).IsRequired().HasMaxLength(20);
            modelBuilder.Entity<BikeFine>().Property(x => x.Amount).IsRequired().HasMaxLength(30);
            modelBuilder.Entity<BikeFine>().Property(x => x.Reason).IsRequired().HasMaxLength(90);
            modelBuilder.Entity<BikeFine>().Property(x => x.CheckNumber).IsRequired().HasMaxLength(25);
            modelBuilder.Entity<BikeFine>().Property(x => x.Gmail).IsRequired().HasMaxLength(35);








            //CarInfo
            modelBuilder.Entity<CarInfo>().HasKey(x => x.Id);
            modelBuilder.Entity<CarInfo>().Property(x => x.CarNumber).IsRequired().HasMaxLength(20);
            modelBuilder.Entity<CarInfo>().Property(x => x.FirstName).IsRequired().HasMaxLength(30);
            modelBuilder.Entity<CarInfo>().Property(x => x.LastName).IsRequired().HasMaxLength(30);
            modelBuilder.Entity<CarInfo>().Property(x => x.FullName).IsRequired().HasMaxLength(30);
            modelBuilder.Entity<CarInfo>().Property(x => x.PhoneNumber).IsRequired().HasMaxLength(15);
            modelBuilder.Entity<CarInfo>().Property(x => x.PersonalNumber).IsRequired().HasMaxLength(25);
            modelBuilder.Entity<CarInfo>().Property(x => x.Address).IsRequired().HasMaxLength(50);



            //BikeInfo
            modelBuilder.Entity<BikeInfo>().HasKey(x => x.Id);
            modelBuilder.Entity<BikeInfo>().Property(x => x.BikeNumber).IsRequired().HasMaxLength(20);
            modelBuilder.Entity<BikeInfo>().Property(x => x.FirstName).IsRequired().HasMaxLength(30);
            modelBuilder.Entity<BikeInfo>().Property(x => x.LastName).IsRequired().HasMaxLength(30);
            modelBuilder.Entity<BikeInfo>().Property(x => x.FullName).IsRequired().HasMaxLength(30);
            modelBuilder.Entity<BikeInfo>().Property(x => x.Address).IsRequired().HasMaxLength(30);
            modelBuilder.Entity<BikeInfo>().Property(x => x.PhoneNumber).IsRequired().HasMaxLength(15);
            modelBuilder.Entity<BikeInfo>().Property(x => x.PersonalNumber).IsRequired().HasMaxLength(25);






            //userroles
            modelBuilder.Entity<User>().HasKey(x => x.Id);
            modelBuilder.Entity<Role>().HasKey(x => x.Id);

            modelBuilder.Entity<UserRole>().HasOne(x => x.User).WithMany(x => x.UserRoles).HasForeignKey(x => x.UserId);
            modelBuilder.Entity<UserRole>().HasOne(x => x.Role).WithMany(x => x.UserRoles).HasForeignKey(x => x.RoleId);

        }


    }
}
