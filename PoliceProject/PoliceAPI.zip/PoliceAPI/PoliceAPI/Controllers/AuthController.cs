using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using PoliceAPI.Dtos;
using PoliceAPI.Entities;
using PoliceAPI.Repositories;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace PoliceAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AuthController : ControllerBase
    {

        private readonly IAuthRepository _authRepository;
        private readonly IConfiguration _config;
        private readonly PoliceApiDbContext _context;

        public AuthController(IAuthRepository authRepository, IConfiguration config, PoliceApiDbContext context)
        {
            _authRepository = authRepository;
            _config = config;
            _context = context;
        }


        [HttpPost("register")]
        public async Task<IActionResult> Register(UserRegisterDto userRegisterDto)
        {
            userRegisterDto.UserName = userRegisterDto.UserName.ToLower();

            if (await _authRepository.UserExsist(userRegisterDto.UserName))
                return BadRequest("Username already exists");

           


            var role = _context.Roles.FirstOrDefault(x => x.Id == userRegisterDto.RoleId);

            if (role == null)
            {
                return BadRequest("This role does not exist");
            }


            var userRolePair = new UserRole()
            {
                RoleId = role.Id
            };

            List<UserRole> userRolePairs = new List<UserRole>();
            userRolePairs.Add(userRolePair);

            User userToCreate = new()
            {

                UserName = userRegisterDto.UserName,
                Created = DateTime.Now,
                UserRoles = userRolePairs
            };

            var createdUser = await _authRepository.Register(userToCreate, userRegisterDto.Password);
          
            return Ok();
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login(UserLoginDto userLoginDto)
        {
            var userFromRepo = await _authRepository.Login(userLoginDto.UserName
                .ToLower(), userLoginDto.Password);

            if (userFromRepo == null)
                return Unauthorized();


            var userRoles = userFromRepo.UserRoles?.Select(ur => ur.Role);

            if (userRoles == null || !userRoles.Any())
                return BadRequest("User does not have any roles.");

            
            var role = userRoles.FirstOrDefault();

            if (role == null)
                return BadRequest("User does not have any valid roles.");

            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier, userFromRepo.Id.ToString()),
                new Claim(ClaimTypes.Name, userFromRepo.UserName),
                new Claim(ClaimTypes.Role, role.RoleName)


            };
           

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config.GetSection("AppSettings:Token").Value));

            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha512Signature);

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),
                //Expires = DateTime.Now.AddDays(1), 
                Expires = DateTime.Now.AddMinutes(20),
                SigningCredentials = creds
            };

            var tokenHandler = new JwtSecurityTokenHandler();

            var token = tokenHandler.CreateToken(tokenDescriptor);

            //var user = _mapper.Map<UserForListDto>(userFromRepo);


            return Ok(new
            {
                token = tokenHandler.WriteToken(token),
                userFromRepo.Id,
                userFromRepo.passwordSalt,
                userFromRepo.passwordHash,
                userFromRepo.Created,
                userFromRepo.UserName,
                RoleId = role.Id,
                RoleName = role.RoleName



            }); ;
        }

    }
}


  
        
    

