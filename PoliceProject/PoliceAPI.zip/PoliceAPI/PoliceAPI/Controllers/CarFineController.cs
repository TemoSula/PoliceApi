﻿using Microsoft.AspNetCore.Mvc;
using PoliceAPI.Dtos;
using PoliceAPI.Entities;
using PoliceAPI.ForEmail;
using PoliceAPI.Repositories;
using PoliceAPI.Services;

namespace PoliceAPI.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class CarFineController : ControllerBase
    {
  
            private readonly ICarFineService _carFineService;
            private readonly IGmailService _gmailService;
            
            public CarFineController(ICarFineService carFineService, IGmailService gmailService, ICarFineRepository carFineRepository)
            {
            _carFineService = carFineService;
            _gmailService = gmailService;
            
            }


            [HttpGet("CheckAndCarNumber")]
            public async Task<ActionResult<CarFineDto>> GetFineForCar(string CarNumber, string CheckNumber)
            {

                var CarFineGet = await _carFineService.GetByCheckAndCarNumber(CarNumber, CheckNumber);
                if (CarFineGet == null)
                {
                    return BadRequest("es nomeri ar moidzebna");

                }

                return Ok(CarFineGet);


            }

        [HttpPost]
        public async Task<ActionResult<CarFineDto>> PostFineOnCarAsync([FromBody] CarFineDto carFineDto)
        {

            var addFineOnCar = await _carFineService.AddFineOnCar(carFineDto);
            if (addFineOnCar == null)
            {
                return BadRequest("es nomeri ar moidzebna");

            }

            try
            {
                MailRequest mailrequest = new MailRequest();
                mailrequest.ToEmail = carFineDto.Gmail;
                mailrequest.Subject = "POLICE DEPARTMENT";
                mailrequest.Body = $"manqanis nomeri: {carFineDto.CarNumber} chekis nomeri: {carFineDto.CheckNumber}";
                await _gmailService.SendEmailAsync(mailrequest);
            }
            catch (Exception ex)
            {
                throw;
            }


            return Ok(addFineOnCar);

        }

        [HttpPut/*("{BikeNumber CheckNumber}")*/]
        public async Task<ActionResult<CarFineDto>> Edit(string CarNumber, string CheckNumber, PayAndStatusForCarDto payAndStatus)
        {

            try
            {
                // Update the status of the bike fine
                var updatedStatus = await _carFineService.UpdateFine(CarNumber, CheckNumber, payAndStatus.PayStatus);

                return Ok(updatedStatus);
            }
            catch (Exception ex)
            {
                // Handle exceptions
                return StatusCode(500, "Internal server error");
            }
        }

    }
}
