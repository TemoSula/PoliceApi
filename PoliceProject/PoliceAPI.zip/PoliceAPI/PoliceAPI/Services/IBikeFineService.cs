﻿using PoliceAPI.Dtos;
using PoliceAPI.Entities;
using System.Runtime.CompilerServices;

namespace PoliceAPI.Services
{
    public interface IBikeFineService
    {
        Task<BikeFineDto> GetByCheckAndBikeNumber(string Bikenumber, string Checknumber);

        Task<BikeFineDto> AddFineOnBike(BikeFineDto bikeFineDto);

        Task<BikeFineDto> Update(string CarNumber,string CheckNumber, string payAndStatus);

    }
}
