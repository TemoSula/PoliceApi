﻿using AutoMapper;
using Azure.Identity;
using Microsoft.EntityFrameworkCore.Storage.Json;
using Microsoft.Extensions.Caching.Distributed;
using PoliceAPI.Dtos;
using PoliceAPI.Entities;
using PoliceAPI.Repositories;
using System.Runtime.CompilerServices;
using Newtonsoft.Json;
using StackExchange.Redis;

namespace PoliceAPI.Services
{
    public class BikeInfoService : IBikeInfoService
    {


        private readonly IbikeInfoRepository _ibikeInfoRepository;
        private readonly IMapper _mapper;
        private readonly IDistributedCache _cache;

        public BikeInfoService(IbikeInfoRepository ibikeInfoRepository, IMapper mapper, IDistributedCache cache)
        {
            _ibikeInfoRepository = ibikeInfoRepository;
            _mapper = mapper;
            _cache = cache;
            
        }

        public IEnumerable<BikeInfoDto> GetAllInfoBike()
        {
            

            var getall = _ibikeInfoRepository.GetAllB().ToList();
            return _mapper.Map<IEnumerable<BikeInfoDto>>(getall);

        }

       public async Task<BikeInfoDto> GetBikeInfoByBikeNumber(string BikeNumber)
        {
            try
            {
                var cacheKey = $"BikeInfoByBikeNumber:{BikeNumber}";

                var CacheData = await _cache.GetStringAsync(cacheKey);

                if (!string.IsNullOrEmpty(CacheData))
                {

                    return JsonConvert.DeserializeObject<BikeInfoDto>(CacheData);
                }


                var getbyid = _ibikeInfoRepository.GetById(BikeNumber);
                var BikeinfoDto = _mapper.Map<BikeInfoDto>(getbyid);

                var CacheOption = new DistributedCacheEntryOptions()
                    .SetSlidingExpiration(TimeSpan.FromMinutes(5))
                    .SetAbsoluteExpiration(TimeSpan.FromHours(1));

                 await _cache.SetStringAsync(cacheKey, JsonConvert.SerializeObject(BikeinfoDto), CacheOption);
           
                return BikeinfoDto;
            }
            catch(RedisConnectionException ex)
            {
                var getbyid = _ibikeInfoRepository.GetById(BikeNumber);
                var BikeinfoDto = _mapper.Map<BikeInfoDto>(getbyid);

                return BikeinfoDto;
            }
        }
        
        public BikeInfoDto AddBikeInfo(BikeInfoDto bikeInfoDto)
        {
            var addBikeInfo = _mapper.Map<BikeInfo>(bikeInfoDto);
            addBikeInfo = _ibikeInfoRepository.CreateBikeInfo(addBikeInfo);
            return _mapper.Map<BikeInfoDto>(addBikeInfo);
        }

    }
}
