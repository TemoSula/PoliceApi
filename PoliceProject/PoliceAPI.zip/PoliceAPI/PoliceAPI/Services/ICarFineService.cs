﻿using PoliceAPI.Dtos;

namespace PoliceAPI.Services
{
    public interface ICarFineService
    {

        Task<CarFineDto> GetByCheckAndCarNumber(string Carnumber, string Checknumber);

        Task<CarFineDto> AddFineOnCar(CarFineDto carFineDto);

        Task<CarFineDto> UpdateFine(string CarNumber, string CheckNumber, string Paystatus);
    }
}
