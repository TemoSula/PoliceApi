﻿using Microsoft.EntityFrameworkCore.ChangeTracking;
using MailKit.Net.Smtp;
using System.Net;
using System;
using PoliceAPI.ForEmail;
using MimeKit;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using MailKit.Security;
using Microsoft.Extensions.Options;

namespace PoliceAPI.Services
{
    public class GmailService : IGmailService

    {
        private readonly EmailSettings _settings;
        public GmailService(IOptions<EmailSettings> options)
        {
            this._settings = options.Value;
        }

        public async Task SendEmailAsync(MailRequest mailRequest)
        {
            var email = new MimeMessage();
            email.Sender = MailboxAddress.Parse(_settings.Email);
            email.To.Add(MailboxAddress.Parse(mailRequest.ToEmail));
            var builder = new BodyBuilder();
            builder.HtmlBody = mailRequest.Body;
            email.Body = builder.ToMessageBody();
            email.Subject = mailRequest.Subject;

            using var smtp = new SmtpClient();
            smtp.Connect(_settings.Host, _settings.Port, SecureSocketOptions.StartTls);
            smtp.Authenticate(_settings.Email, _settings.Password);
            await smtp.SendAsync(email);
            smtp.Disconnect(true);

        }
    }
}
    