﻿using PoliceAPI.Dtos;

namespace PoliceAPI.Services
{
    public interface IBikeInfoService
    {

        IEnumerable<BikeInfoDto> GetAllInfoBike();

        Task<BikeInfoDto> GetBikeInfoByBikeNumber(string BikeNumber);

        BikeInfoDto AddBikeInfo(BikeInfoDto bikeInfoDto);

        





    }
}
