﻿namespace PoliceWPF
{
    partial class IdentifyCarNumber
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnGetCarNumber = new Button();
            txtCarNumber = new TextBox();
            richResponse = new RichTextBox();
            SuspendLayout();
            // 
            // btnGetCarNumber
            // 
            btnGetCarNumber.Location = new Point(146, 37);
            btnGetCarNumber.Name = "btnGetCarNumber";
            btnGetCarNumber.Size = new Size(133, 42);
            btnGetCarNumber.TabIndex = 1;
            btnGetCarNumber.Text = "GetCarNumber";
            btnGetCarNumber.UseVisualStyleBackColor = true;
            btnGetCarNumber.Click += btnGetCarNumber_Click;
            // 
            // txtCarNumber
            // 
            txtCarNumber.Location = new Point(321, 48);
            txtCarNumber.Name = "txtCarNumber";
            txtCarNumber.Size = new Size(196, 23);
            txtCarNumber.TabIndex = 2;
            // 
            // richResponse
            // 
            richResponse.Location = new Point(12, 108);
            richResponse.Name = "richResponse";
            richResponse.Size = new Size(730, 330);
            richResponse.TabIndex = 3;
            richResponse.Text = "";
            // 
            // IdentifyCarNumber
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(754, 450);
            Controls.Add(richResponse);
            Controls.Add(txtCarNumber);
            Controls.Add(btnGetCarNumber);
            FormBorderStyle = FormBorderStyle.None;
            Name = "IdentifyCarNumber";
            Text = "IdentifyCarNumber";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button btnGetCarNumber;
        private TextBox txtCarNumber;
        private RichTextBox richResponse;
    }
}