﻿using PoliceWPF.deserializeandserialize;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using Microsoft.IdentityModel.Tokens;

namespace PoliceWPF
{
    public partial class CarFine : Form
    {
        public CarFine()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblCheckNumber_Click(object sender, EventArgs e)
        {

        }

        private async void btnCreate_Click(object sender, EventArgs e)
        {
            //txtCarNumberF.Mask = ">LL-000-LL";
            //es arit imisatbis rom ar dairgves kontexti da chanaweri iyos specialuri
            
            string url = "http://localhost:5022";
            string pattern = @"^[A-Z]{2}-\d{3}-[A-Z]{2}$";
            string GmailPattern = @"^[a-zA-Z0-9._%+-]+@gmail\.com$";

            string carnumber = txtCarNumberF.Text;
            string amount = txtAmount.Text;
            string reason = txtReason.Text;
            string gmail = txtGmail.Text.Trim();
            string paystatus = txtPayStatus.Text;

            Random randomForCheck = new Random();
            string checkNumberRandom = "";

            for (int i = 0; i < 8; i++)
            {

                checkNumberRandom += randomForCheck.Next(1, 9);

            }

            


            try
            {
                if (carnumber.IsNullOrEmpty())
                {
                    MessageBox.Show("gtxovt sheavsot carnumber veli");
                }
                else if (!Regex.IsMatch(txtCarNumberF.Text, pattern))
                {

                    MessageBox.Show("Please enter the car number in the format LL-000-LL.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else if (amount.IsNullOrEmpty())
                {
                    MessageBox.Show("Gtxovt Sheavsot amount veli");
                }
                else if (reason.IsNullOrEmpty())
                {
                    MessageBox.Show("Gtxovt Sheavsot reason veli");
                }
                else if (gmail.IsNullOrEmpty())
                {
                    MessageBox.Show("Gtxovt Sheavsot gmail veli");
                }
                else if (!Regex.IsMatch(gmail, GmailPattern)) 
                {
                    MessageBox.Show("gtxovt sheavsot gmail veli amgvarad google@gmail.com");

                }
                else if (paystatus.IsNullOrEmpty())
                {
                    MessageBox.Show("Gtxovt Sheavsot paystatus veli");
                }
                else
                {

                    MessageBox.Show("Jarima Warmatebit gaigzavna");

                    CarFineDto carFineDto = new()
                    {

                        carNumber = txtCarNumberF.Text,
                        Amount = Convert.ToDecimal(txtAmount.Text),
                        Reason = txtReason.Text,
                        CheckNumber = checkNumberRandom,
                        Gmail = txtGmail.Text,
                        payStatus = txtPayStatus.Text

                    };

                    comunication comunications = new comunication(url);
                    var response = await comunications.PostCarFine(carFineDto);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Resursi ar moidzebna");

            }

        }
    }
}
