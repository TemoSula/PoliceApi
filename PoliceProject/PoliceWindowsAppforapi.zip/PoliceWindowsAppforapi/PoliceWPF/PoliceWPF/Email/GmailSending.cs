﻿using MimeKit;
using System;
using System.Collections.Generic;
using System.Linq;
using MailKit.Net.Smtp;
//using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using MailKit.Security;

namespace PoliceWPF.Email
{
    internal class GmailSending
    {

        private readonly EmailSettings _settings;
        public GmailSending()
        {
             _settings = new EmailSettings();
        }

        public async Task SendMailAsync(MailRequest mailRequest) 
        {

            var email = new MimeMessage();
            email.Sender = MailboxAddress.Parse(_settings.Email);
            email.To.Add(MailboxAddress.Parse(mailRequest.ToEmail));
            var builder = new BodyBuilder();
            builder.TextBody = mailRequest.Body;
            email.Body = builder.ToMessageBody();
            email.Subject = mailRequest.Subject;

            using var smtp = new SmtpClient();
            smtp.Connect(_settings.Host, _settings.Port, SecureSocketOptions.StartTls);
            smtp.Authenticate(_settings.Email,_settings.Password);
            await smtp.SendAsync(email);
            smtp.Disconnect(true);
        
        }

    }
}
