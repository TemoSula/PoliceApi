﻿using Guna.UI2.WinForms;
using Microsoft.IdentityModel.Tokens;
using PoliceWPF.deserializeandserialize;
using PoliceWPF.Dtos;
using PoliceWPF.Email;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PoliceWPF
{
    public partial class PayCarFine : Form
    {
        public PayCarFine()
        {
            InitializeComponent();
        }

        private async void btnGetCarFine_Click(object sender, EventArgs e)
        {

            string CarNumber = txtCarNumberFine.Text;
            string CheckNumberForCarFine = txtCarCheckNumber.Text;
            
            try
            {


                string pattern = @"^[A-Z]{2}-\d{3}-[A-Z]{2}$";

                if (!Regex.IsMatch(CarNumber, pattern))
                {

                    MessageBox.Show("Gtxovt Sheiyvanot Monacemebi Msgavsad LL-000-LL");
                    return;
                }
                else if (CheckNumberForCarFine.IsNullOrEmpty()) 
                {

                    MessageBox.Show("Gtxovt Sheavsot Checkis veli");

                }
                string url = "http://localhost:5022";
                comunication communication = new comunication(url);
                var response = await communication.GetCarFine(CarNumber, CheckNumberForCarFine);
                richTextForCarFine.Text = comunication.BeutyfyJson(response);
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Resursi ar moidzebna");
            }
           



            //string url = "http://localhost:5022";
            //comunication communication = new comunication(url);
            //var response = await communication.GetCarFine(CarNumber, CheckNumberForCarFine);
            //richTextForCarFine.Text = comunication.BeutyfyJson(response);



        }
        private bool codeSent = false;
        private int expectedCode ;
        private async void button1_Click(object sender, EventArgs e)
        {

            //Input Information
            string CardNumber = txtCardNumber.Text;
            string Date = txtDate.Text;
            string HideCode = txtHideCode.Text;
            string CarNumber = txtCarNumberFine.Text;
            string CheckNumber = txtCarCheckNumber.Text;
            string RandomCodeInput = TxtCodeGetter.Text;

            //string TransactionCashOut = $"http://localhost:5066/Transaction/CashOut";
            string urlForCheckBalanceOnCreditCard = $"http://localhost:5066/PaymentCard/CardNumber?CardNumber={CardNumber}";

            string changeStatusUrl = $"http://localhost:5022/api/CarFine?CarNumber={CarNumber}&CheckNumber={CheckNumber}";
            string transactionCashOut = $"http://localhost:5066/Transaction/CashOut";
            string urlForCarFineCheck = $"http://localhost:5022/api/CarFine/CheckAndCarNumber?CarNumber={CarNumber}&CheckNumber={CheckNumber}";

            try {
                //for Generate code before Transaction
                var random = new Random();

                var GetRandomCode = "";
                for (int i = 1; i < 5; i++)
                {

                    GetRandomCode += random.Next(1, 5);

                }
                //stringi gardavqmenit intad
                int NumberInInt = Convert.ToInt32(GetRandomCode);


                using (HttpClient client = new HttpClient())
                {
                    // Call API to check balance on credit card
                    HttpResponseMessage responseCard = await client.GetAsync(urlForCheckBalanceOnCreditCard);
                    responseCard.EnsureSuccessStatusCode();
                    var resultCard = await responseCard.Content.ReadAsStringAsync();
                    var cardData = JsonSerializer.Deserialize<CardNumber>(resultCard);

                    // Call API to check Car fine
                    HttpResponseMessage responseBike = await client.GetAsync(urlForCarFineCheck);
                    responseBike.EnsureSuccessStatusCode();
                    string resultCar = await responseBike.Content.ReadAsStringAsync();
                    var CarData = JsonSerializer.Deserialize<GetCarFineForCheck>(resultCar);
                    Console.WriteLine($"This is your fine amount: {CarData.amount}");

                    decimal fineAmount = CarData.amount;
                    string Gmail = cardData.email.ToString();
                    //tu lmoxda kliki buttonze pirveli igzavneba kodi da meore klikeze cdilobs gaaqtiuros da gadaixados
                    if (!codeSent)
                    {
                        // Send code via email
                        var emailsending = new GmailSending();
                        var requestmail = new MailRequest();
                        requestmail.ToEmail = Gmail; // Change to the recipient's email address
                        requestmail.Subject = "PayCode";
                        requestmail.Body = $"Your code is: {NumberInInt}"; // Use your generated code here
                        await emailsending.SendMailAsync(requestmail);

                        MessageBox.Show("Code sent via email");
                        codeSent = true;
                        expectedCode = NumberInInt; // Store the expected code
                    }
                    else
                    {

                        if (RandomCodeInput != expectedCode.ToString())
                        {

                            MessageBox.Show("Mititebui kodi arasworia");

                        }
                        else
                        {

                            //es gadaamowmebs aris tu ara gadaxdili jarima da tu aris mashi is 
                            if (CarData.payStatus == "Paid")
                            {
                                //Console.WriteLine("Tqven ukve gadaxdili gaqvt");
                                MessageBox.Show("Tqven ukve gadaxdili gaqvt");

                            }


                            else
                            {

                                //vcadot gaigzavnos mailze ramdeni davxarjet da ramdenia balansze
                                // Check if card balance is sufficient to cover the fine
                                if (cardData.balance >= fineAmount)
                                {
                                    // Deduct fine amount from card balance
                                    // cardData.balance -= fineAmount;
                                    MessageBox.Show("Gadaxda warmateluad moxda");
                                    var reaminCash = cardData.balance - fineAmount;
                                    var emailsending = new GmailSending();
                                    var requestmail = new MailRequest();
                                    requestmail.ToEmail = Gmail;
                                    requestmail.Subject = "GadaxdaShesrulebulia";
                                    requestmail.Body = $"gadaxdili tanxaa {fineAmount} balansze arsebuli tanxa{reaminCash}";
                                    emailsending.SendMailAsync(requestmail);
                                    // Pay the fine
                                    var postStruct = new CashOutCard()
                                    {
                                        cardNumber = CardNumber,
                                        cardData = Date,
                                        hideCode = HideCode,
                                        balance = fineAmount
                                    };

                                    HttpResponseMessage responseTransaction = await client.PostAsync(transactionCashOut, new StringContent(JsonSerializer.Serialize(postStruct), Encoding.UTF8, "application/json"));
                                    responseTransaction.EnsureSuccessStatusCode();

                                    // Update status to "Paid"
                                    var status = new Status()
                                    {
                                        payStatus = "Paid"
                                    };

                                    HttpResponseMessage responseStatus = await client.PutAsync(changeStatusUrl, new StringContent(JsonSerializer.Serialize(status), Encoding.UTF8, "application/json"));
                                    responseStatus.EnsureSuccessStatusCode();
                                }
                                else
                                {
                                    //vcadot es gaigzavnos meilze
                                    //Console.WriteLine("tqven ar gaqvt sakmarisi tanxa");
                                    MessageBox.Show("tqven ar gaqvt sakmarisi tanxa");
                                    // Update status to "Unpaid" as there is insufficient balance
                                    var status = new Status()
                                    {
                                        payStatus = "Unpaid"
                                    };

                                    HttpResponseMessage responseStatus = await client.PutAsync(changeStatusUrl, new StringContent(JsonSerializer.Serialize(status), Encoding.UTF8, "application/json"));
                                    responseStatus.EnsureSuccessStatusCode();
                                }
                            }

                        }

                    }
        }
            }
            catch (Exception ex) 
            {
                MessageBox.Show("mititebuli barati arasworia");
            }
        }
    }
}
