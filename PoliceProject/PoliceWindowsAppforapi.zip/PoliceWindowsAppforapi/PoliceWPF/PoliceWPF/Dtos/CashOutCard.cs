﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PoliceWPF.Dtos
{
    internal class CashOutCard
    {

        public string cardNumber { get; set; }

        public string cardData { get; set; }

        public string hideCode { get; set; }

        public decimal balance { get; set; }

    }
}
