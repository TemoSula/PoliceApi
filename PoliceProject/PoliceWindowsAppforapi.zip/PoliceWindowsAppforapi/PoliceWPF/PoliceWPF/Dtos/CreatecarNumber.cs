﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PoliceWPF.Dtos
{
    internal class CreatecarNumber
    {

        public string carNumber { get; set; }
        public string fullName { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public long phoneNumber { get; set; }
        public long personalNumber { get; set; }
        public string address { get; set; }

    }
}
