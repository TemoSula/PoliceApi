﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PoliceWPF.Dtos
{
    internal class Status
    {
        public string payStatus { get; set; }

    }
}
