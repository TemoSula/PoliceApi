﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PoliceWPF.Dtos
{
    internal class CardNumber
    {

        public string firstName { get; set; }
        public string lastName { get; set; }
        public string fullName { get; set; }
        public string cardNumber { get; set; }
        public string cardData { get; set; }
        public string hideCode { get; set; }
        public string email { get; set; }
        public decimal balance { get; set; }

    }
}
