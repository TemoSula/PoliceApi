﻿using Microsoft.IdentityModel.Tokens;
using PoliceWPF.deserializeandserialize;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Transactions;
using System.Windows.Forms;

namespace PoliceWPF
{
    public partial class BikeFine : Form
    {
        public BikeFine()
        {
            InitializeComponent();
        }

        private async void  btnCreateB_Click(object sender, EventArgs e)
        {
 

            string url = "http://localhost:5022";

            string pattern = @"^[A-Z]{2}-\d{4}$";
            string GmailPattern = @"^[a-zA-Z0-9._%+-]+@gmail\.com$";
            string bikeNumber = txtBikeNumberF.Text;
            string amount = txtAmountBike.Text;
            string reason = txtReasonBike.Text;
            string gmail  = txtGmailB.Text;
            string paystatus = txtPaystatus.Text;


            //random checkNumber
            Random randomForCheck = new Random();
            string checkNumberRandom = "";

            for (int i = 0; i < 8; i++) 
            {

                checkNumberRandom += randomForCheck.Next(1,9);

            }

            //int GenerateCheckNumber = Convert.ToInt32(checkNumberRandom);
           

            try
            {

                if (bikeNumber.IsNullOrEmpty())
                {

                    MessageBox.Show("gtxovt sheavsot bikenumber  veli");

                }

                else if (!Regex.IsMatch(bikeNumber, pattern))
                {

                    MessageBox.Show("Please enter the car number in the format LL-000-LL.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;

                }
                else if (amount.IsNullOrEmpty())
                {
                    MessageBox.Show("gtxovt sheavsot amount veli");
                }
                else if (reason.IsNullOrEmpty())
                {
                    MessageBox.Show("gtxovt shavsot reason veli");

                }
                else if (gmail.IsNullOrEmpty())
                {
                    MessageBox.Show("gtxovt shavsot gmail veli");

                }
                else if (!Regex.IsMatch(gmail, GmailPattern)) 
                {
                    MessageBox.Show("Gtxovt Sheavsot Gmail Veli amggvarad google@gmail.com");
                }
                else if (paystatus.IsNullOrEmpty())
                {
                    MessageBox.Show("gtxovt shavsot paystatus veli");

                }
                else
                {

                    MessageBox.Show("Jarima Warmatebit gaigzavna");

                    BikeFineDto bikeFineDto = new()
                    {
                        bikeNumber = bikeNumber,
                        Amount = Convert.ToDecimal(amount),
                        CheckNumber = checkNumberRandom,
                        Reason = reason,
                        Gmail = gmail,
                        payStatus = paystatus


                    };



                    comunication communication = new comunication(url);
                    var response = await communication.PostBikeFine(bikeFineDto);
                }
            }
            catch  (Exception ex) 
            {

                MessageBox.Show("Resursi Ar moidzebna");
            
            }
        }
    }
}
