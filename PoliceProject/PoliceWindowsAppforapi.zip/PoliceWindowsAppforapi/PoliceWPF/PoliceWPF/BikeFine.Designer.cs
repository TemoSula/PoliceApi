﻿namespace PoliceWPF
{
    partial class BikeFine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnCreateB = new Button();
            label2 = new Label();
            txtReasonBike = new TextBox();
            lbl = new Label();
            lblAmount = new Label();
            txtGmailB = new TextBox();
            txtAmountBike = new TextBox();
            label1 = new Label();
            txtBikeNumberF = new TextBox();
            label3 = new Label();
            txtPaystatus = new TextBox();
            SuspendLayout();
            // 
            // btnCreateB
            // 
            btnCreateB.Location = new Point(292, 334);
            btnCreateB.Name = "btnCreateB";
            btnCreateB.Size = new Size(145, 36);
            btnCreateB.TabIndex = 21;
            btnCreateB.Text = "Create";
            btnCreateB.UseVisualStyleBackColor = true;
            btnCreateB.Click += btnCreateB_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(60, 156);
            label2.Name = "label2";
            label2.Size = new Size(45, 15);
            label2.TabIndex = 20;
            label2.Text = "Reason";
            // 
            // txtReasonBike
            // 
            txtReasonBike.Location = new Point(151, 148);
            txtReasonBike.Name = "txtReasonBike";
            txtReasonBike.Size = new Size(140, 23);
            txtReasonBike.TabIndex = 19;
            // 
            // lbl
            // 
            lbl.AutoSize = true;
            lbl.Location = new Point(361, 156);
            lbl.Name = "lbl";
            lbl.Size = new Size(38, 15);
            lbl.TabIndex = 18;
            lbl.Text = "Gmail";
            // 
            // lblAmount
            // 
            lblAmount.AutoSize = true;
            lblAmount.Location = new Point(361, 72);
            lblAmount.Name = "lblAmount";
            lblAmount.Size = new Size(51, 15);
            lblAmount.TabIndex = 17;
            lblAmount.Text = "Amount";
            // 
            // txtGmailB
            // 
            txtGmailB.Location = new Point(447, 148);
            txtGmailB.Name = "txtGmailB";
            txtGmailB.Size = new Size(140, 23);
            txtGmailB.TabIndex = 16;
            // 
            // txtAmountBike
            // 
            txtAmountBike.Location = new Point(447, 64);
            txtAmountBike.Name = "txtAmountBike";
            txtAmountBike.Size = new Size(140, 23);
            txtAmountBike.TabIndex = 15;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(60, 72);
            label1.Name = "label1";
            label1.Size = new Size(73, 15);
            label1.TabIndex = 13;
            label1.Text = "BikeNumber";
            // 
            // txtBikeNumberF
            // 
            txtBikeNumberF.Location = new Point(151, 64);
            txtBikeNumberF.Name = "txtBikeNumberF";
            txtBikeNumberF.Size = new Size(140, 23);
            txtBikeNumberF.TabIndex = 11;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(250, 238);
            label3.Name = "label3";
            label3.Size = new Size(58, 15);
            label3.TabIndex = 23;
            label3.Text = "PayStatus";
            // 
            // txtPaystatus
            // 
            txtPaystatus.Location = new Point(345, 235);
            txtPaystatus.Name = "txtPaystatus";
            txtPaystatus.Size = new Size(140, 23);
            txtPaystatus.TabIndex = 22;
            // 
            // BikeFine
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new Size(800, 450);
            Controls.Add(label3);
            Controls.Add(txtPaystatus);
            Controls.Add(btnCreateB);
            Controls.Add(label2);
            Controls.Add(txtReasonBike);
            Controls.Add(lbl);
            Controls.Add(lblAmount);
            Controls.Add(txtGmailB);
            Controls.Add(txtAmountBike);
            Controls.Add(label1);
            Controls.Add(txtBikeNumberF);
            FormBorderStyle = FormBorderStyle.None;
            Name = "BikeFine";
            Text = "BikeFine";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnCreateB;
        private Label label2;
        private TextBox txtReasonBike;
        private Label lbl;
        private Label lblAmount;
        private TextBox txtGmailB;
        private TextBox txtAmountBike;
        private Label label1;
        private TextBox txtBikeNumberF;
        private Label label3;
        private TextBox txtPaystatus;
    }
}