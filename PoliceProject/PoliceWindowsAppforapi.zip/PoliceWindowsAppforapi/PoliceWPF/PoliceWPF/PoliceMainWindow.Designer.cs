﻿namespace PoliceWPF
{
    partial class PoliceMainWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PoliceMainWindow));
            panelSide = new Panel();
            button3 = new Button();
            button2 = new Button();
            btnBikeFine = new Button();
            pictureBox1 = new PictureBox();
            btnCarFine = new Button();
            btnIdentifyBike = new Button();
            btnIdentifyCar = new Button();
            panelHeader = new Panel();
            button1 = new Button();
            MainPanel = new Panel();
            panelSide.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panelHeader.SuspendLayout();
            SuspendLayout();
            // 
            // panelSide
            // 
            panelSide.BackColor = SystemColors.ControlDarkDark;
            panelSide.Controls.Add(button3);
            panelSide.Controls.Add(button2);
            panelSide.Controls.Add(btnBikeFine);
            panelSide.Controls.Add(pictureBox1);
            panelSide.Controls.Add(btnCarFine);
            panelSide.Controls.Add(btnIdentifyBike);
            panelSide.Controls.Add(btnIdentifyCar);
            panelSide.Dock = DockStyle.Left;
            panelSide.Location = new Point(0, 30);
            panelSide.Name = "panelSide";
            panelSide.Size = new Size(200, 420);
            panelSide.TabIndex = 0;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.ControlDarkDark;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button3.ForeColor = SystemColors.Menu;
            button3.Location = new Point(3, 359);
            button3.Name = "button3";
            button3.Size = new Size(191, 35);
            button3.TabIndex = 6;
            button3.Text = "CreateBikeNumber";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ControlDarkDark;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button2.ForeColor = SystemColors.Menu;
            button2.Location = new Point(6, 306);
            button2.Name = "button2";
            button2.Size = new Size(191, 35);
            button2.TabIndex = 5;
            button2.Text = "CreateCarNumber";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // btnBikeFine
            // 
            btnBikeFine.BackColor = SystemColors.ControlDarkDark;
            btnBikeFine.FlatStyle = FlatStyle.Flat;
            btnBikeFine.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBikeFine.ForeColor = SystemColors.Menu;
            btnBikeFine.Location = new Point(6, 250);
            btnBikeFine.Name = "btnBikeFine";
            btnBikeFine.Size = new Size(191, 35);
            btnBikeFine.TabIndex = 3;
            btnBikeFine.Text = "BikeFine";
            btnBikeFine.UseVisualStyleBackColor = false;
            btnBikeFine.Click += btnBikeFine_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(54, 6);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(85, 85);
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // btnCarFine
            // 
            btnCarFine.BackColor = SystemColors.ControlDarkDark;
            btnCarFine.FlatStyle = FlatStyle.Flat;
            btnCarFine.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCarFine.ForeColor = SystemColors.Menu;
            btnCarFine.Location = new Point(6, 200);
            btnCarFine.Name = "btnCarFine";
            btnCarFine.Size = new Size(191, 35);
            btnCarFine.TabIndex = 2;
            btnCarFine.Text = "CarFine";
            btnCarFine.UseVisualStyleBackColor = false;
            btnCarFine.Click += btnCarFine_Click;
            // 
            // btnIdentifyBike
            // 
            btnIdentifyBike.BackColor = SystemColors.ControlDarkDark;
            btnIdentifyBike.FlatStyle = FlatStyle.Flat;
            btnIdentifyBike.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnIdentifyBike.ForeColor = SystemColors.Menu;
            btnIdentifyBike.Location = new Point(3, 148);
            btnIdentifyBike.Name = "btnIdentifyBike";
            btnIdentifyBike.Size = new Size(191, 35);
            btnIdentifyBike.TabIndex = 1;
            btnIdentifyBike.Text = "IdentifyBikeNumber";
            btnIdentifyBike.UseVisualStyleBackColor = false;
            btnIdentifyBike.Click += btnIdentifyBike_Click;
            // 
            // btnIdentifyCar
            // 
            btnIdentifyCar.BackColor = SystemColors.ControlDarkDark;
            btnIdentifyCar.FlatStyle = FlatStyle.Flat;
            btnIdentifyCar.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnIdentifyCar.ForeColor = SystemColors.Menu;
            btnIdentifyCar.Location = new Point(6, 97);
            btnIdentifyCar.Name = "btnIdentifyCar";
            btnIdentifyCar.Size = new Size(191, 35);
            btnIdentifyCar.TabIndex = 0;
            btnIdentifyCar.Text = "IdentifyCarNumber";
            btnIdentifyCar.UseVisualStyleBackColor = false;
            btnIdentifyCar.Click += btnIdentifyCar_Click;
            // 
            // panelHeader
            // 
            panelHeader.BackColor = SystemColors.ControlDarkDark;
            panelHeader.Controls.Add(button1);
            panelHeader.Dock = DockStyle.Top;
            panelHeader.Location = new Point(0, 0);
            panelHeader.Name = "panelHeader";
            panelHeader.Size = new Size(912, 30);
            panelHeader.TabIndex = 1;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ControlDarkDark;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Century Gothic", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = SystemColors.Menu;
            button1.Location = new Point(874, 0);
            button1.Name = "button1";
            button1.Size = new Size(35, 29);
            button1.TabIndex = 5;
            button1.Text = "X";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // MainPanel
            // 
            MainPanel.Dock = DockStyle.Fill;
            MainPanel.Location = new Point(200, 30);
            MainPanel.Name = "MainPanel";
            MainPanel.Size = new Size(712, 420);
            MainPanel.TabIndex = 2;
            MainPanel.Paint += MainPanel_Paint;
            // 
            // PoliceMainWindow
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(912, 450);
            Controls.Add(MainPanel);
            Controls.Add(panelSide);
            Controls.Add(panelHeader);
            FormBorderStyle = FormBorderStyle.None;
            Name = "PoliceMainWindow";
            Text = "PoliceMainWindow";
            panelSide.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panelHeader.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panelSide;
        private Panel panelHeader;
        private Button btnIdentifyCar;
        private Panel MainPanel;
        private Button btnBikeFine;
        private Button btnCarFine;
        private Button btnIdentifyBike;
        private PictureBox pictureBox1;
        private Button button1;
        private Button button3;
        private Button button2;
    }
}