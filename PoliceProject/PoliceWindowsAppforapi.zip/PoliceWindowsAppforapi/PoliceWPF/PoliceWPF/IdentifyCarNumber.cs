﻿using Microsoft.IdentityModel.Tokens;
using PoliceWPF.deserializeandserialize;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PoliceWPF
{
    public partial class IdentifyCarNumber : Form
    {
        public IdentifyCarNumber()
        {
            InitializeComponent();
        }

        private async void btnGetCarNumber_Click(object sender, EventArgs e)
        {
            string CarNumber = txtCarNumber.Text;
            string pattern = @"^[A-Z]{2}-\d{3}-[A-Z]{2}$";
            string baseUrl = "http://localhost:5022/";

            try
            {
                if (CarNumber.IsNullOrEmpty())
                {
                    MessageBox.Show("gtxovt sheavsot CarNumber Veli");


                } else if (!Regex.IsMatch(CarNumber, pattern)) 
                {
                    MessageBox.Show("gtxovt sheiyvanot CarNumberi amgvarad LL-234-LL");
                
                }

               
                
                comunication GetCarInfo = new comunication(baseUrl);
                var carInfo = await GetCarInfo.GetCarWithNumber(CarNumber);
                richResponse.Text = comunication.BeutyfyJson(carInfo);
            }
            catch (Exception ex) 
            {

                MessageBox.Show("resursi ar moidzebna");

            }

        }
    }

}
    
