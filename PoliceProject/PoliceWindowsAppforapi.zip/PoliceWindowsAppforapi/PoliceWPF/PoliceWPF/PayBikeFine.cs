﻿//using Newtonsoft.Json;
using System.Text.Json;
using PoliceWPF.deserializeandserialize;
using PoliceWPF.Dtos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PoliceWPF.Email;
using System.Text.RegularExpressions;
using Microsoft.IdentityModel.Tokens;
using Org.BouncyCastle.Asn1.X509;

namespace PoliceWPF
{
    public partial class PayBikeFine : Form
    {
        public PayBikeFine()
        {
            InitializeComponent();
        }

        private async void btnGetBikeFine_Click(object sender, EventArgs e)
        {


            /* string CarNumber = txtCarNumberFine.Text;
            string CheckNumberForCarFine = txtCarCheckNumber.Text;
            
            try
            {


                string pattern = @"^[A-Z]{2}-\d{3}-[A-Z]{2}$";

                if (!Regex.IsMatch(CarNumber, pattern))
                {

                    MessageBox.Show("Gtxovt Sheiyvanot Monacemebi Msgavsad LL-000-LL");
                    return;
                }
                else if (CheckNumberForCarFine.IsNullOrEmpty()) 
                {

                    MessageBox.Show("Gtxovt Sheavsot Checkis veli");

                }
                string url = "http://localhost:5022";
                comunication communication = new comunication(url);
                var response = await communication.GetCarFine(CarNumber, CheckNumberForCarFine);
                richTextForCarFine.Text = comunication.BeutyfyJson(response);
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Resursi ar moidzebna");
            }
           */

            string BikeNumberForFine = txtBikeNumberFine.Text;
            string CheckNumberForBikeFine = txtBikeCheckNumber.Text;

            try
            {


                string pattern = @"^[A-Z]{2}-\d{4}$";

                if (!Regex.IsMatch(BikeNumberForFine, pattern))
                {

                    MessageBox.Show("Please enter the car number in the format LL-0000.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                else if (CheckNumberForBikeFine.IsNullOrEmpty())
                {

                    MessageBox.Show("Gtxovt Sheavsot Checkis veli");

                }
                else
                {

                    string url = "http://localhost:5022";
                    comunication communication = new comunication(url);
                    var response = await communication.GetBikeFine(BikeNumberForFine, CheckNumberForBikeFine);
                    richTextForBikeFine.Text = comunication.BeutyfyJson(response);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Resursi ar moidzebna");
            }



            //string url = "http://localhost:5022";
            //comunication communication = new comunication(url);
            //var response = await communication.GetBikeFine(BikeNumberForFine, CheckNumberForBikeFine);
            //richTextForBikeFine.Text = comunication.BeutyfyJson(response);



        }
        private bool codeSent = false;
        private int expectedCode ;

        private async void button1_Click(object sender, EventArgs e)
        {
            string CardNumber = txtCardNumber.Text;
            string Date = txtDate.Text;
            string HideCode = txtHideCode.Text;
            string BikeNumber = txtBikeNumberFine.Text;
            string CheckNumber = txtBikeCheckNumber.Text;
            string PayCode = TxtCodesGetter.Text;

            string TransactionCashOut = $"http://localhost:5066/Transaction/CashOut";
            //string cardNumber = "1650 4633 0170 7291";
            //string datas = "10/25";
            //string HideCode = "100000";

            // string cardNumber = "1650 4633 0170 7291";
            string urlForCheckBalanceOnCreditCard = $"http://localhost:5066/PaymentCard/CardNumber?CardNumber={CardNumber}";
            //string bikeNumber = "BE-5555";
            //string checkNumber = "1111111111";
            //http://localhost:5022/api/BikeFine?BikeNumber=BE-5555&CheckNumber=99320293
            string changeStatusUrl = $"http://localhost:5022/api/BikeFine?BikeNumber={BikeNumber}&CheckNumber={CheckNumber}";
            string transactionCashOut = $"http://localhost:5066/Transaction/CashOut";
            string urlForBikeFineCheck = $"http://localhost:5022/api/BikeFine/CheckAndBikeNumber?BikeNumber={BikeNumber}&CheckNumber={CheckNumber}";

            try { 
            var random = new Random();

            var GetRandomCode = "";
            for (int i = 1; i < 5; i++)
            {

                GetRandomCode += random.Next(1, 5);

            }
            int NumberInInt = Convert.ToInt32(GetRandomCode);


                using (HttpClient client = new HttpClient())
                {
                    // Call API to check balance on credit card
                    HttpResponseMessage responseCard = await client.GetAsync(urlForCheckBalanceOnCreditCard);
                    responseCard.EnsureSuccessStatusCode();
                    var resultCard = await responseCard.Content.ReadAsStringAsync();
                    var cardData = JsonSerializer.Deserialize<CardNumber>(resultCard);

                    // Call API to check bike fine
                    HttpResponseMessage responseBike = await client.GetAsync(urlForBikeFineCheck);
                    responseBike.EnsureSuccessStatusCode();
                    string resultBike = await responseBike.Content.ReadAsStringAsync();
                    var bikeData = JsonSerializer.Deserialize<GetBikeFineForCheck>(resultBike);
                   //Console.WriteLine($"This is your fine amount: {bikeData.amount}");

                    decimal fineAmount = bikeData.amount;
                    string Gmail = cardData.email.ToString();


                    if (!codeSent)
                    {
                        // Send code via email
                        var emailsending = new GmailSending();
                        var requestmail = new MailRequest();
                        // Change to the recipient's email address

                        requestmail.ToEmail = Gmail;

                        requestmail.Subject = "PayCode";

                        requestmail.Body = $"Your code is: {NumberInInt}"; // Use your generated code here
                        await emailsending.SendMailAsync(requestmail);

                        MessageBox.Show("Code sent via email");
                        codeSent = true;
                        expectedCode = NumberInInt; // Store the expected code
                    }

                    else
                    {

                        if (PayCode != expectedCode.ToString())
                        {

                            MessageBox.Show("Mititebui kodi arasworia");

                        }
                        else
                        {

                            //es gadaamowmebs aris tu ara gadaxdili jarima da tu aris mashi is 
                            if (bikeData.payStatus == "Paid")
                            {
                                //Console.WriteLine("Tqven ukve gadaxdili gaqvt");
                                MessageBox.Show("Tqven ukve gadaxdili gaqvt");

                            }

                            else
                            {

                                //vcadot gaigzavnos mailze ramdeni davxarjet da ramdenia balansze
                                // Check if card balance is sufficient to cover the fine
                                if (cardData.balance >= fineAmount)
                                {
                                    MessageBox.Show("gadaxda warmatebit shesrulda");
                                    // Deduct fine amount from card balance
                                    // cardData.balance -= fineAmount;
                                    var reaminCash = cardData.balance - fineAmount;
                                    var emailsending = new GmailSending();
                                    var requestmail = new MailRequest();
                                    requestmail.ToEmail = Gmail;
                                    requestmail.Subject = "GadaxdaShesrulebulia";
                                    requestmail.Body = $"gadaxdili tanxaa {fineAmount} balansze arsebuli tanxa{reaminCash} jarima: {bikeData.bikeNumber}  {bikeData.checkNumber}";
                                    emailsending.SendMailAsync(requestmail);


                                    // Pay the fine
                                    var postStruct = new CashOutCard()
                                    {
                                        cardNumber = CardNumber,
                                        cardData = Date,
                                        hideCode = HideCode,
                                        balance = fineAmount
                                    };

                                    HttpResponseMessage responseTransaction = await client.PostAsync(transactionCashOut, new StringContent(JsonSerializer.Serialize(postStruct), Encoding.UTF8, "application/json"));
                                    responseTransaction.EnsureSuccessStatusCode();

                                    // Update status to "Paid"
                                    var status = new Status()
                                    {
                                        payStatus = "Paid"
                                    };

                                    HttpResponseMessage responseStatus = await client.PutAsync(changeStatusUrl, new StringContent(JsonSerializer.Serialize(status), Encoding.UTF8, "application/json"));
                                    responseStatus.EnsureSuccessStatusCode();
                                }
                                else
                                {
                                    //vcadot es gaigzavnos meilze
                                    //Console.WriteLine("tqven ar gaqvt sakmarisi tanxa");
                                    MessageBox.Show("tqven ar gaqvt sakmarisi tanxa");
                                    // Update status to "Unpaid" as there is insufficient balance
                                    var status = new Status()
                                    {
                                        payStatus = "Unpaid"
                                    };

                                    HttpResponseMessage responseStatus = await client.PutAsync(changeStatusUrl, new StringContent(JsonSerializer.Serialize(status), Encoding.UTF8, "application/json"));
                                    responseStatus.EnsureSuccessStatusCode();
                                }
                            }
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("mititebuli barati arasworia");
            }
        }
    }
 }
