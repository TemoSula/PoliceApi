﻿using Microsoft.IdentityModel.Tokens;
using Org.BouncyCastle.Asn1.X509;
using PoliceWPF.Dtos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PoliceWPF
{
    public partial class CreateBikeNumber : Form
    {
        public CreateBikeNumber()
        {
            InitializeComponent();
        }

        private async void button1_Click(object sender, EventArgs e)
        {

            string url = "http://localhost:5022/api/BikeInfo";
            string pattern = @"^[A-Z]{2}-\d{4}$";


            string bikeNumber = txtBikeNumber.Text;
            string firstName = txtFirstNameB.Text;
            string lastName = txtLastNameB.Text;
            string phoneNumber = txtPhoneNumberB.Text;
            string personalNumber = txtPersonalNumberB.Text;
            string address = txtAddressB.Text;


            using (HttpClient client = new HttpClient()) {

                try
                {
                    if (bikeNumber.IsNullOrEmpty())
                    {
                        MessageBox.Show("gtxovt Sheavsot BikeNumber Veli");


                    }
                    else if (!Regex.IsMatch(bikeNumber, pattern))
                    {

                        MessageBox.Show("gtxovt sheiyvanot bikeNumber amgvarad LL-2354 ");

                    }
                    else if (firstName.IsNullOrEmpty())
                    {

                        MessageBox.Show("Gtxovt Sheavsot firstName Veli ");

                    }
                    else if (lastName.IsNullOrEmpty())
                    {

                        MessageBox.Show("Gtxovt Sheavsot lastName Veli ");

                    }
                    else if (phoneNumber.IsNullOrEmpty())
                    {

                        MessageBox.Show("Gtxovt Sheavsot phoneNumber Veli ");

                    }
                    else if (phoneNumber.Length != 9) 
                    {
                        MessageBox.Show("gtxovt sheiyvanot phoneNumber swored");
                    }

                    else if (personalNumber.IsNullOrEmpty())
                    {

                        MessageBox.Show("Gtxovt Sheavsot personalNumber Veli ");
                    }
                    else if (personalNumber.Length != 11)
                    {
                        MessageBox.Show("gtxovt sheiyvanot personalNumber Veli sworad");
                    }
                    else if (address.IsNullOrEmpty())
                    {

                        MessageBox.Show("Gtxovt Sheavsot FullName Veli ");

                    }
                    else
                    {

                        MessageBox.Show("motocikletis nomeri  Warmatebit daemata ");

                        var CreateBikeNumber = new CreatebikeNumber()
                        {
                            bikeNumber = bikeNumber,
                            fullName = /*FullName*/ firstName + " " + lastName,
                            firstName = firstName,
                            lastName = lastName,
                            phoneNumber = Convert.ToInt64(phoneNumber),
                            personalNumber = Convert.ToInt64(personalNumber),
                            address = address
                        };
                        /*carNumber = txtCarNumber.Text,
                            firstName = txtFirstName.Text,
                            lastName = txtLastName.Text,
                            phoneNumber = Convert.ToInt32(txtPhoneNumber.Text),
                            personalNumber = Convert.ToInt32(txtPersonalNumber.Text),
                            address = txtAddress.Text*/
                        //phoneNumber = Convert.ToInt32(txtPhoneNumber.Text),
                        HttpResponseMessage response = await client.PostAsync(url, new StringContent(JsonSerializer.Serialize(CreateBikeNumber), Encoding.UTF8, "application/json"));
                        response.EnsureSuccessStatusCode();
                    }
                }catch (Exception ex) 
                {
                    MessageBox.Show("jarima ar gaigzvna");
                
                }
            }
        }
    }
}
