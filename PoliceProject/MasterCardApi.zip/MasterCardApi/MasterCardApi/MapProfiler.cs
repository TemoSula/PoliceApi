﻿using AutoMapper;
using MasterCardApi.Dtos;
using MasterCardApi.Entities;

namespace MasterCardApi
{
    public class MapProfiler : Profile
    {

        public MapProfiler()
        {
            CreateMap<UserCards, UserCardsDto>().ReverseMap();
            CreateMap<UserCards, TransactionDto>().ReverseMap();
        }


    }
}
