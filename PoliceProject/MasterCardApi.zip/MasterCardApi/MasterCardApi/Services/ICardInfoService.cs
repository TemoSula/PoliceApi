﻿using MasterCardApi.Dtos;
using MasterCardApi.Entities;


namespace MasterCardApi.Services
{
    public interface ICardInfoService
    {

        IEnumerable<UserCardsDto> GetAllCardsD();
        UserCardsDto CrateNewCardD(GenerateCardOptionsDto generateCard);
        UserCardsDto GetCardbyNumberD(string CardNumber);



    }
}
