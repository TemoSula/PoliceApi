﻿using AutoMapper;
using MasterCardApi.Dtos;
using MasterCardApi.Entities;
using MasterCardApi.Repository;

namespace MasterCardApi.Services
{
    public class TransactionService : ITransactionService
    {
        private readonly ICardInfoRepository _cardInfoRepository;
        private readonly IMapper _mapper;
        public TransactionService(ICardInfoRepository cardInfoRepository, IMapper mapper)
        {
            _cardInfoRepository = cardInfoRepository;
            _mapper = mapper;
        }

        public TransactionDto CashInTransaction(TransactionDto transactionDto)
        {
            var user = _cardInfoRepository.GetCardbyNumber(transactionDto.CardNumber);
            user.Balance += transactionDto.Balance;
            _cardInfoRepository.Transaction(user.CardNumber,user.Balance);
            return _mapper.Map<TransactionDto>(user);
        }

        public TransactionDto CashOut(TransactionDto transactionDto)
        {
            var user = _cardInfoRepository.GetCardbyNumber(transactionDto.CardNumber);
            user.Balance -= transactionDto.Balance;
            _cardInfoRepository.Transaction(user.CardNumber,user.Balance);
            return _mapper.Map<TransactionDto>(user);
        }
    }
}