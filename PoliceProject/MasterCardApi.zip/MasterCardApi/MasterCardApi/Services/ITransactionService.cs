﻿using MasterCardApi.Dtos;
using MasterCardApi.Entities;

namespace MasterCardApi.Services
{
    public interface ITransactionService
    {

        TransactionDto CashInTransaction(TransactionDto transactionDto);
        TransactionDto CashOut(TransactionDto MinutransactionDtosBalance);


    }
}
