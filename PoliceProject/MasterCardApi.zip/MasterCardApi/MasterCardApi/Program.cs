using MasterCardApi.Entities;
using MasterCardApi.Repository;
using MasterCardApi.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;

namespace MasterCardApi
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            builder.Services.AddControllers();
            builder.Services.AddDbContext<PaymentContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
            builder.Services.AddAutoMapper(typeof(Program));
            builder.Services.AddScoped<ICardInfoRepository, CardInfoRepository>();
            builder.Services.AddScoped<ICardInfoService, CardInfoService>();
            builder.Services.AddScoped<ITransactionService, TransactionService>();

            builder.Services.AddSwaggerGen();

            var app = builder.Build();

           


            app.UseSwagger();
            app.UseSwaggerUI();

            app.MapControllers();
            app.Run();
        }
    }
}
