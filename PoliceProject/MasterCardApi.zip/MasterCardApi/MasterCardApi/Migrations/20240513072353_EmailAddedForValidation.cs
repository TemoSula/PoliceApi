﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MasterCardApi.Migrations
{
    /// <inheritdoc />
    public partial class EmailAddedForValidation : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Email",
                table: "UserCards",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Email",
                table: "UserCards");
        }
    }
}
