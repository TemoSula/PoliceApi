﻿namespace MasterCardApi.Dtos
{
    public class GenerateCardOptionsDto
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public string Email { get; set; }

    }
}
