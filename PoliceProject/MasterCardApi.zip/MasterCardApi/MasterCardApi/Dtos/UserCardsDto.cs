﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace MasterCardApi.Dtos
{
    public class UserCardsDto
    {

        //public int Id { get; set; }

        public string FullName { get; set; }

        public string CardNumber { get; set; }

        public string CardData { get; set; }

        public string HideCode { get; set; }

        public string Email { get; set; }

        public decimal Balance { get; set; }

    }
}
